# MiniProjectConsumerApp
Rest Mini Project Consumer App (Part - II)

## Output

![Snap](https://github.com/yogendrajava86/MiniProjectConsumerApp/blob/master/RestMiniProjectConsumer.png)
